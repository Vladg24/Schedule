<?php
$username = "u699038206_vlad";
$password = "123456";
$servername = "mysql.hostinger.com.ua";
$db_name = "u699038206_bkeip";
$conn = mysqli_connect($servername, $username, $password, $db_name);

mysqli_set_charset($conn,"utf8");


$sql = "select distinct name_group from groups";
  
$result = mysqli_query($conn, $sql);

$response = array();
if ($result > 0) 
{
	While($row=mysqli_fetch_array($result))
	{
	array_push($response,array("name_group"=>$row["name_group"]));
	
	}
}
echo json_encode($response,JSON_UNESCAPED_UNICODE);

?>