<?php
/*
 * Загрузка файла на сервер
 * Автор: Mowshon (Live-code.ru)
 * Дата: 11.11.13
 */

// Максимально допустимый размер загружаемого файла - 5Мб
$MaxFileSizeInBytes = 5242880;
// Разрешение расширения файлов для загрузки
$AllowFileExtension = array('jpg', 'png', 'jpeg', 'gif', 'rar', 'zip', 'doc', 'docx' , 'pdf', 'djvu');
// Оригинальное название файла
$FileName = $_FILES['uploaded_file']['name'];
// Полный путь до временного файла
$TempName = $_FILES['uploaded_file']['tmp_name'];
// Папка где будут загружатся файлы
$UploadDir = "uploads/";
// Полный путь к новому файлу в папке сервера
$NewFilePatch = $UploadDir.$FileName;
if($FileName) {
    // Проверка если расширение файла находится в массиве доступных
    $FileExtension = pathinfo($FileName, PATHINFO_EXTENSION);
    if(!in_array($FileExtension, $AllowFileExtension)) {
        echo "Файлы с расширением {$FileExtension} не допускаются";
    }
     else {
         // Проверка размера файла
         if(filesize($TempName) > $MaxFileSizeInBytes) {
             echo "Размер загружаемого файла превышает 5МБ";
         }
          else {
              // Проверяем права доступа на папку
              if(!is_writable($UploadDir)) {
                  echo "Папка ".$UploadDir." не имеет прав на запись";
              }
               else {
                   // Копируем содержимое временного файла $TempName и создаем нового в папке сервера
                   $CopyFile = copy($TempName, $NewFilePatch);
                   if(!$CopyFile) {
                       echo "Возникла ошибка, файл не удалось загрузить!";
                   }
                    else {
                        echo "Файл успешно загружен!<br />Ссылка на файл: <a href='{$NewFilePatch}'>{$NewFilePatch}</a>";
                    }
               }
          }
     }
}
?>