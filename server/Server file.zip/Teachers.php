﻿<?php
$username = "u699038206_vlad";
$password = "123456";
$servername = "mysql.hostinger.com.ua";
$db_name = "u699038206_bkeip";
$conn = mysqli_connect($servername, $username, $password, $db_name);

mysqli_set_charset($conn,"utf8");

$name_group = $_REQUEST[name_group];
//$name_group= "КН-13";

$sql = "select distinct teacher.name_teacher, aud.num from teacher, groups, disciplines ,aud
where groups.name_group='$name_group' and groups.IDGroup=disciplines.IDGroup and teacher.IDTeacher=disciplines.IDTeacher and teacher.IDTeacher = aud.IDAud";
  
$result = mysqli_query($conn, $sql);

$response = array();
if ($result > 0) 
{
	While($row=mysqli_fetch_array($result))
	{
	array_push($response,array("name_teacher"=>$row["name_teacher"],"num"=>$row["num"]));
	
	}
}
echo json_encode($response,JSON_UNESCAPED_UNICODE);

?>